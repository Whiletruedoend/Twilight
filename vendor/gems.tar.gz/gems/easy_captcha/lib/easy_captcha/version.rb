module EasyCaptcha
  VERSION = '0.6.5'
end
